# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['data_spy']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2>=3.1.2,<4.0.0',
 'SQLAlchemy>=1.4.43,<2.0.0',
 'click>=8.1.3,<9.0.0',
 'pandas>=1.5.1,<2.0.0',
 'python-decouple>=3.6,<4.0',
 'snowflake-connector-python[pandas]>=2.8.1,<3.0.0',
 'snowflake-sqlalchemy>=1.4.3,<2.0.0',
 'tabulate>=0.9.0,<0.10.0']

entry_points = \
{'console_scripts': ['data-spy = data_spy.data_spy:main']}

setup_kwargs = {
    'name': 'data-spy',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Anthony Khoudary',
    'author_email': 'ankhoudary12@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
